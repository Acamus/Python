# Load libraries
import pandas
from pandas.tools.plotting import scatter_matrix
import matplotlib.pyplot as plt
from sklearn import model_selection	
from sklearn.linear_model import LinearRegression
from sklearn.metrics import mean_squared_error
from sklearn.metrics import classification_report
from sklearn.metrics import confusion_matrix
from sklearn.metrics import accuracy_score
from sklearn.linear_model import LogisticRegression
from sklearn.tree import DecisionTreeClassifier
from sklearn.neighbors import KNeighborsClassifier
from sklearn.discriminant_analysis import LinearDiscriminantAnalysis
from sklearn.naive_bayes import GaussianNB
from sklearn.svm import SVC
import csv


# Read the file and store the read file in a variable
f_reader1=file('tot_cr_txn_after.csv','r')
f_config1=file('config1.properties','r')
f_config2=file('config2.properties','r')
f_config3=file('config3.properties','r')

f_check=csv.reader('f_reader1')
f_configFile_rea1=csv.reader('f_config1')
f_configFile_reader2=csv.reader('f_config2')
f_configFile_reader3=csv.reader('f_config3')

# Write our output in a file
f_writeLow=file('abnormal_report1.csv','w')
f_writeToLow=csv.writer(f_writeLow)
f_writeMedium=file('abnormal_report2.csv','w')
f_writeToMedium=csv.writer(f_writeMedium)
f_writeHigh=file('abnormal_report3.csv','w')
f_writeToHigh=csv.writer(f_writeHigh)


# for loop 1 for Low Salaried Customer to detect fadulent/abnoraml
for l_all_data in f_check:
	l_abnormal=False
	#for l_configurableFile in f_configFile_reader1:
	l_check_abnormal=l_all_data
	l_check_abnormal.to_csv(path='report.csv',sep=',')
	if l_all_data[0] >=  15000:
		l_check_abnormal.append('Abnormal')
		l_abnormal=True
		break
	if not l_abnormal:
		l_check_abnormal.append('Normal')
	f_writeToLow.writerow(l_check_abnormal)
	

"""

# for loop 1 for Medium Salaried Customer to detect fadulent/abnoraml
for m_all_data in f_check:
	m_abnormal=False
	for m_configurableFile in f_configFile_reader2:
		m_check_abnormal=m_all_data
		if m_all_data[3] <= m_configurableFile[3]:
			m_check_abnormal.append('Abnormal')
			m_abnormal=True
			break
	if not m_abnormal:
		m_check_abnormal.append('Normal')
	f_writeToMedium.writerow(m_check_abnormal)
	
# for loop 1 for High Salaried Customer to detect fadulent/abnoraml
for h_all_data in f_check:
	h_abnormal=False
	for h_configurableFile in f_configFile_reader3:
		h_check_abnormal=h_all_data
		if  h_all_data[3] <= h_configurableFile[3]:
			h_check_abnormal.append('Abnormal')
			h_abnormal=True
			break
	if not h_abnormal:
		h_check_abnormal.append('Normal')
	f_writeToHigh.writerow(h_check_abnormal)

"""

f_reader1.close()
f_config1.close()
f_config2.close()
f_config3.close()
	
